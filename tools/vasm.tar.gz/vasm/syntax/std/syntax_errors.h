  "mnemonic expected",ERROR,
  "invalid extension",ERROR,
  "no space before operands",WARNING,
  "too many closing parentheses",WARNING,
  "missing closing parentheses",WARNING,
  "missing operand",ERROR,                        /* 5 */
  "scratch at end of line",WARNING,
  "section flags expected",ERROR,
  "invalid data operand",ERROR,
  "memory flags expected",ERROR,
  "identifier expected",ERROR,                    /* 10 */
  "assembly aborted",ERROR,
  "unexpected \"%s\" without \"%s\"",ERROR,
  "pointless default value for required parameter <%s>",ERROR,
  "invalid section type ignored, assuming progbits",WARNING,
  "",ERROR,                                       /* 15 */
  "",ERROR,
  "",ERROR,
  "syntax error",ERROR,
  "",ERROR,
  "section name expected",ERROR,                  /* 20 */
  ".fail %lld encountered",WARNING,
  ".fail %lld encountered",ERROR,
  "alignment too big",WARNING,
