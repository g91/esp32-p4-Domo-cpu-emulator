  "sections must not overlap",FATAL|ERROR|NOLINE,
  "output module doesn't support cpu %s",ERROR|NOLINE,
  "write error",FATAL|ERROR|NOLINE,
  "section attributes <%s> not supported",ERROR|NOLINE,
  "reloc type %d, size %u, mask 0x%lx (symbol %s + 0x%lx) not supported",ERROR|NOLINE,
  "reloc type %d not supported",ERROR|NOLINE,                       /* 05 */
  "undefined symbol <%s>",ERROR|NOLINE,
  "output module doesn't allow multiple sections of the same type (%s)",FATAL|ERROR|NOLINE,
  "undefined symbol <%s> at %s+0x%lx, reloc type %d",ERROR,
  "section <%s>: alignment padding (%lu) not a multiple of %lu at 0x%llx",WARNING|NOLINE,
  "weak symbol <%s> not supported by output format, treating as global",WARNING|NOLINE, /* 10 */
  "address 0x%llx out of range for selected format",ERROR|NOLINE,
  "reloc type %d, mask 0x%lx to symbol %s + 0x%lx does not fit into %u bits",ERROR,
  "data definition following a databss space directive",WARNING,
